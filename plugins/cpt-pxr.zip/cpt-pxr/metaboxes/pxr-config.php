<?php
/**
 * Get current theme options
 * 
 * @return array
 */

if ( defined( 'CMB2_LOADED' ) ) {
    /**
     * Add Metaboxes
     * @param array $meta_boxes
     * @return array 
     */

    add_action( 'cmb2_admin_init', 'pxr_cmb2_metaboxes' );
    /**
     * Define the metabox and field configurations.
     */
    if ( !function_exists( 'pxr_cmb2_metaboxes' ) ) {
        function pxr_cmb2_metaboxes() {

            $pxr = 'pxr_';

            /**
             * Initiate the metabox
             */
            $pxr_info = new_cmb2_box( array(
                'id'            => $pxr . 'main-section',
                'title'         => __( 'Main Section', 'cpt-pxr' ),
                'object_types'  => array( 'page', ), // Post type
                'context'       => 'normal',
                'priority'      => 'high',
                'show_names'    => true, // Show field names on the left
                // 'cmb_styles' => false, // false to disable the CMB stylesheet
                // 'closed'     => true, // Keep the metabox closed by default
            ) );

            // Regular text field
            $pxr_info->add_field( array(
                'name'       => __( 'Test Text', 'cpt-pxr' ),
                'desc'       => __( 'field description (optional)', 'cpt-pxr' ),
                'id'         => $pxr . 'fivis',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', 
            ) );

             $pxr_info->add_field( array(
                'name'    => 'Категории',
                'id'      => $pxr . 'pxr_page_home_cases_select_term',
                'type'    => 'pw_multiselect',
                'options' => array(
                    'check1' => 'Check One',
                    'check2' => 'Check Two',
                    'check3' => 'Check Three',
                ),
            ) );

      
            // Add other metaboxes as needed
        }
    }
}

