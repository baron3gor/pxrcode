<?php
/**
 * Add admin scripts and styles
 */
if ( !function_exists( 'pxr_add_scripts' ) ) {
	function pxr_add_scripts($hook) {
		
		// Add general scripts & styles
		wp_enqueue_style('pxr-admin-css', PXR_CORE_PLUGIN_URL . '/assets/css/admin.css', array(), PXR_CORE_VERSION);
		wp_register_style( 'pxr-fontawesome', PXR_CORE_PLUGIN_URL . '/assets/css/font-awesome.min.css', array(), PXR_CORE_VERSION, 'all');

	    wp_enqueue_script( 'pxr-megamenu-check', PXR_CORE_PLUGIN_URL . '/assets/js/megamenu.js', array( 'jquery' ), PXR_CORE_VERSION, true );


	    wp_enqueue_style('pxr-fontawesome');


		// Add scripts for metaboxes
	  	if ( $hook == 'post.php' || $hook == 'post-new.php' || $hook == 'page-new.php' || $hook == 'page.php' ) {

		    wp_enqueue_script('pxr-metabox-gallery', PXR_CORE_PLUGIN_URL . '/assets/js/metabox-gallery.js', array('jquery', 'jquery-ui-sortable'));
	    }
	}
}

add_action( 'admin_enqueue_scripts', 'pxr_add_scripts', 10 );


