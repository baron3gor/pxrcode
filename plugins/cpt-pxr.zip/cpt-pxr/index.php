<?php 
//Silent is golden