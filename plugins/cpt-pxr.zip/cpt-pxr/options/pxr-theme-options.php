<?php
/**
* ReduxFramework Sample Config File
* For full documentation, please visit: http://docs.reduxframework.com/
*/

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    require_once ('theme-options/typography/class-redux-typography.php');


    // This is your option name where all the Redux data is stored.
    $opt_name = "pxr_red_option";

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'pxr Options', 'cpt-pxr' ),
        'page_title'           => esc_html__( 'pxr Options', 'cpt-pxr' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => true,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

// -> START General
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'General', 'cpt-pxr' ),
        'desc'             => esc_html__( 'General Settings', 'cpt-pxr' ),
        'id'               => 'general-section',
        'fields'           => array(
            array(
                'id'       => 'logo-img',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Logo image', 'cpt-pxr' ),
                'subtitle'     => __( 'Upload the logo image. ', 'cpt-pxr' ),
            ),
        )
    ) );


// -> START Typography
    Redux::setSection( $opt_name, array(
        'title'  => esc_html__( 'Typography', 'cpt-pxr' ),
        'desc'   => esc_html__( 'Typography Settings', 'cpt-pxr'),
        'id'     => 'typography-section',
        'icon'   => 'el el-font',
        'fields' => array(
            array(
                'id'       => 'pxr-font-body',
                'type'     => 'typography',
                'title'    => esc_html__( 'Body Font', 'cpt-pxr' ),
                'subtitle' => esc_html__( 'Specify the body font properties.', 'cpt-pxr' ),
                'desc'     => esc_html__( 'Insert the font for body.', 'cpt-pxr' ),
                'google'   => false,
                'font-style' => false,
                'font-weight' => false,
                'line-height' => true,
                'text-align'  => false,
                'letter-spacing' => false,
                'visibility'  => false,
                'opacity' => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'body' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'body' ),
                'default'  => array(
                    'color'       => '#4e413b',
                    'font-size'   => '16px',
                    'font-family' => 'Lato',
                    'line-height' => '26px'

                ),
            ),

            array(
                'id'          => 'pxr-font-h1',
                'type'        => 'typography',
                'title'       => esc_html__( 'Typography h1', 'cpt-pxr' ),
                'google'   => true,
                'line-height' => true,
                'letter-spacing' => false,
                'text-align'  => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'h1' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'h1' ),
                // An array of CSS selectors to apply this font style to dynamically
                'units'       => 'px',
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for H1 title.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#000000',
                    'font-weight' => '400',
                    'font-family' => 'Muli',
                    'font-size'   => '68px',
                    'line-height' => '84px',
                ),
            ),

            array(
                'id'          => 'pxr-font-h2',
                'type'        => 'typography',
                'title'       => esc_html__( 'Typography h2', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'line-height' => true,
                'letter-spacing' => false,
                'text-align'  => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'h2' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'h2' ),
                // An array of CSS selectors to apply this font style to dynamically
                'units'       => 'px',
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for H2 title.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#000000',
                    'font-weight' => '400',
                    'font-family' => 'Muli',
                    'font-size'   => '47px',
                    'line-height' => '56px',
                ),
            ),
            array(
                'id'          => 'pxr-font-h3',
                'type'        => 'typography',
                'title'       => esc_html__( 'Typography h3', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'line-height' => true,
                'letter-spacing' => false,
                'text-align'  => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'h3' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'h3' ),
                // An array of CSS selectors to apply this font style to dynamically
                'units'       => 'px',
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for H3 title.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#000000',
                    'font-weight'  => '400',
                    'font-family' => 'Muli',
                    'font-size'   => '36px',
                    'line-height' => '47px',
                ),
            ),
            array(
                'id'          => 'pxr-font-h4',
                'type'        => 'typography',
                'title'       => esc_html__( 'Typography h4', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'line-height' => true,
                'text-align'  => false,
                'letter-spacing' => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'h4' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'h4' ),
                // An array of CSS selectors to apply this font style to dynamically
                'units'       => 'px',
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for H4 title.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#000000',
                    'font-weight'  => '400',
                    'font-family' => 'Muli',
                    'font-size'   => '27px',
                    'line-height'   => '38px',
                ),
            ),
            array(
                'id'          => 'pxr-font-h5',
                'type'        => 'typography',
                'title'       => esc_html__( 'Typography h5', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'line-height' => true,
                'text-align'  => false,
                'letter-spacing' => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'h5' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'h5' ),
                // An array of CSS selectors to apply this font style to dynamically
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for H5 title.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#000000',
                    'font-weight' => '400',
                    'font-family' => 'Muli',
                    'font-size'   => '19px',
                    'line-height' => '28px',
                ),
            ),
            array(
                'id'          => 'pxr-font-h6',
                'type'        => 'typography',
                'title'       => esc_html__( 'Typography h6', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'text-align'  => false,
                'line-height' => true,
                'letter-spacing' => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'h6' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'h6' ),
                // An array of CSS selectors to apply this font style to dynamically
                'units'       => 'px',
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for H6 title.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#4e413b',
                    'font-weight'  => '400',
                    'font-family' => 'Lato',
                    'font-style'  => 'italic',
                    'font-size'   => '17px',
                    'line-height' => '24px',
                ),
            ),


            array(
                'id'          => 'pxr-menu-navigations',
                'type'        => 'typography',
                'title'       => esc_html__( 'Menu Navigations', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'line-height' => true,
                'letter-spacing' => false,
                'text-align'  => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'nav.pxr-nav-wrapper li, span.scroll-down-button, .header-swiper-pagination, .widget_pages ul li, .widget_nav_menu ul li, .mobile-nav .menu li' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'nav.pxr-nav-wrapper li,  span.scroll-down-button, .header-swiper-pagination, .widget_pages ul li, .widget_nav_menu ul li, .mobile-nav .menu li' ),
                // An array of CSS selectors to apply this font style to dynamically
                'units'       => 'px',
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for navigations.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#4e413b',
                    'font-weight' => '400',
                    'font-family' => 'Muli',
                    'font-size'   => '14px',
                    'line-height'   => '14px',
                ),
            ),

            array(
                'id'          => 'pxr-inputs',
                'type'        => 'typography',
                'title'       => esc_html__( 'Inputs and Textarea', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'letter-spacing' => false,
                'line-height' => true,
                'text-align'  => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'input, textarea' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'input, textarea' ),
                // An array of CSS selectors to apply this font style to dynamically
                'units'       => 'px',
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for Inputs and Textareas.', 'cpt-pxr' ),
                'default'     => array(
                    'font-weight'  => '400',
                    'font-family' => 'Lato',
                    'font-size'   => '17px',
                    'line-height' => '27px',
                ),
            ),


            array(
                'id'          => 'pxr-buttons',
                'type'        => 'typography',
                'title'       => esc_html__( 'Buttons', 'cpt-pxr' ),
                'google'   => true,
                'all_styles'  => true,
                'line-height' => false,
                'text-align'  => false,
                'letter-spacing' => false,
                // Enable all Google Font style/weight variations to be added to the page
                'output'      => array( 'button' ),
                // An array of CSS selectors to apply this font style to dynamically
                'compiler'    => array( 'button' ),
                // An array of CSS selectors to apply this font style to dynamically
                // Defaults to px
                'subtitle'    => esc_html__( 'Insert the font for buttons.', 'cpt-pxr' ),
                'default'     => array(
                    'color'       => '#ff6d24',
                    'font-weight'  => '600',
                    'font-family' => 'Muli',
                    'font-size'   => '14px',  
                ),
            ),
        )
    ) );

    // -> Google maps settings
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Google Maps', 'cpt-pxr' ),
        'desc'             => esc_html__( 'Google Maps Settings', 'cpt-pxr' ),
        'id'               => 'google-maps-section',
        'icon'             => 'fa fa-map-marker',
        'fields'           => array(
            array(
                'id'       => 'google-maps-api',
                'type'     => 'text',
                'title'    => esc_html__( 'Google API Key', 'cpt-pxr' ),
                'desc'     => esc_html__( 'Enter your Google API key. Refer online documentation of the theme to learn how to get your API key.', 'cpt-pxr' ),
            ),

            array(
                'id'       => 'google-maps-marker',
                'type'     => 'color',
                'title'    => esc_html__( 'Google Map Marker Color', 'cpt-pxr' ),
                'desc'     => esc_html__( 'Insert the color for google maps markers.', 'cpt-pxr' ),
                'default'  => '#ff6d24',
            ),

            array(
                'id'       => 'google-maps-marker-stroke',
                'type'     => 'color',
                'title'    => esc_html__( 'Google Map Marker Stroke Color', 'cpt-pxr' ),
                'desc'     => esc_html__( 'Insert the stroke color for google maps markers.', 'cpt-pxr' ),
                'default'  => '#4e413b',
            ),
        )
    ) );

