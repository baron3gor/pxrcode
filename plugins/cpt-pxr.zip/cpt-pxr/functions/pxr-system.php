<?php 

/**
 * Initialize Theme Support Features 
 */
function pxr_init_theme_support() {
    if (function_exists('pxr_get_images_sizes')) {
        foreach (pxr_get_images_sizes() as $post_type => $sizes) {
            foreach ($sizes as $config) {
                pxr_add_image_size($post_type, $config);
            }
        }
    }
}
add_action('init', 'pxr_init_theme_support');

function pxr_after_setup_theme() {
    // add editor style for admin editor
    add_editor_style();

    // add post thumbnails support
    add_theme_support('post-thumbnails');
    
    // add needed post formats to theme
    if (function_exists('pxr_get_post_formats')) {
        add_theme_support('post-formats', pxr_get_post_formats());
    }
}
add_action('after_setup_theme', 'pxr_after_setup_theme');

/**
 * Initialize Theme Navigation 
 */
function pxr_init_navigation() {
    if (function_exists('register_nav_menus')) {
        register_nav_menus(array(
            'pxr_header_menu'   => esc_html__('Header Menu', 'cpt-pxr'),
            'pxr_sticky_left'   => esc_html__('Sticky Left Menu', 'cpt-pxr'),
            'pxr_mobile_menu'   => esc_html__('Mobile Menu', 'cpt-pxr'),
        ));
    }
}
add_action('init', 'pxr_init_navigation');

/**
 * Add custom image size wrapper
 * @param string $post_type
 * @param array $config 
 */
function pxr_add_image_size($post_type, $config) {
    add_image_size($config['name'], $config['width'], $config['height'], $config['crop']);
}

// THIS INCLUDES THE THUMBNAIL IN OUR RSS FEED
function pxr_insert_feed_image($content) {
global $post;

if ( has_post_thumbnail( $post->ID ) ){
    $content = ' ' . get_the_post_thumbnail( $post->ID, 'medium' ) . " " . $content;
}
return $content;
}

add_filter('the_excerpt_rss', 'pxr_insert_feed_image');
add_filter('the_content_rss', 'pxr_insert_feed_image');



/**
 * Deregister default scripts and styles
 * 
 * @return array
 */


// Disable dashicons
add_action( 'wp_print_styles',     'my_deregister_styles', 100 );

function my_deregister_styles()    { 
   wp_deregister_style( 'dashicons' ); 
}

//Disable emojis in WordPress
add_action( 'init', 'smartwp_disable_emojis' );

function smartwp_disable_emojis() {
  remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
  remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
  remove_action( 'wp_print_styles', 'print_emoji_styles' );
  remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
  remove_action( 'admin_print_styles', 'print_emoji_styles' );
  remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
  remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
  add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
}

function disable_emojis_tinymce( $plugins ) {
  if ( is_array( $plugins ) ) {
    return array_diff( $plugins, array( 'wpemoji' ) );
  } else {
    return array();
  }
}
/* Disable the Admin Bar. */
add_filter( 'show_admin_bar', '__return_false' );

/* Remove admin bar */
remove_action('init', 'wp_admin_bar_init');

/* Remove wp-embed.min.js */

function my_deregister_scripts(){
  wp_deregister_script( 'wp-embed' );
}
add_action( 'wp_footer', 'my_deregister_scripts' );